import concurrent.futures as cf
import datetime, hashlib, json, random, re, subprocess, urllib.request
from pathlib import Path

DEST = Path.home() / 'Documents/Tenzen/Instagram users'
TMP = Path('/tmp/instagram-users-collection')
LOG = Path.home() / '.claude/progress/Instagram-users-progress.md'
GROUPS = {
 'North America': [('united-states','United States',5),('canada','Canada',5)],
 'Latin America and Caribbean': [('mexico','Mexico',2),('brazil','Brazil',2),('argentina','Argentina',2),('colombia','Colombia',2),('jamaica','Jamaica',2)],
 'Northern and Western Europe': [('united-kingdom','United Kingdom',2),('france','France',2),('germany','Germany',2),('sweden','Sweden',2),('netherlands','Netherlands',2)],
 'Southern and Eastern Europe': [('spain','Spain',2),('italy','Italy',2),('greece','Greece',2),('poland','Poland',2),('romania','Romania',2)],
 'Middle East and North Africa': [('morocco','Morocco',2),('egypt','Egypt',2),('saudi-arabia','Saudi Arabia',2),('united-arab-emirates','United Arab Emirates',2),('turkey','Turkey',2)],
 'Sub-Saharan Africa': [('nigeria','Nigeria',2),('kenya','Kenya',2),('south-africa','South Africa',2),('ghana','Ghana',2),('tanzania','Tanzania',2)],
 'South Asia': [('india','India',2),('pakistan','Pakistan',2),('bangladesh','Bangladesh',2),('sri-lanka','Sri Lanka',2),('nepal','Nepal',2)],
 'East Asia': [('japan','Japan',3),('south-korea','South Korea',3),('taiwan','Taiwan',2),('hong-kong','Hong Kong',2)],
 'Southeast Asia': [('indonesia','Indonesia',2),('philippines','Philippines',2),('vietnam','Vietnam',2),('thailand','Thailand',2),('malaysia','Malaysia',2)],
 'Oceania': [('australia','Australia',4),('new-zealand','New Zealand',4),('fiji','Fiji',2)]
}

def fetch(url):
 req=urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
 with urllib.request.urlopen(req, timeout=25) as r:
  return r.read(), r.headers.get('Content-Type','')

def candidates(task):
 region,slug,country,count=task
 url='https://www.modash.io/find-influencers/'+slug
 try:
  raw,_=fetch(url)
  text=raw.decode()
  (TMP/(slug+'.html')).write_bytes(raw)
  pattern=r'username:"([^"\\]+)",bio:[\s\S]*?,url:"(https://www\.instagram\.com/[^"\\]+)",pictureUrl:"([^"\\]+)"[\s\S]*?,location:"([^"\\]+)"'
  rows=[]
  for m in re.finditer(pattern,text):
   username,profile_url,picture_url,location=m.groups()
   if re.fullmatch(r'[A-Za-z0-9_.]{1,30}',username):
    rows.append(dict(username=username,profile_url=profile_url,profile_picture_source_url=picture_url,country_or_territory=country,region=region,source_location=location,source_page=url))
  rows=list({r['username']:r for r in rows}.values())
  print(slug,len(rows),'requested',count,flush=True)
  return dict(region=region,slug=slug,country=country,requested=count,candidates=rows)
 except Exception as e:
  print(slug,'ERROR',str(e),flush=True)
  return dict(region=region,slug=slug,country=country,requested=count,candidates=[],error=str(e))

if __name__=='__main__':
 tasks=[(region,*c) for region,countries in GROUPS.items() for c in countries]
 with cf.ThreadPoolExecutor(max_workers=6) as pool:
  pools=list(pool.map(candidates,tasks))
 (TMP/'pools.json').write_text(json.dumps(pools,ensure_ascii=False,indent=2))
 with LOG.open('a') as f:f.write('| Tool run | Collected country candidate pools from public Modash directories; results in /tmp/instagram-users-collection/pools.json. |\n')
 print('TOTAL',sum(len(p['candidates']) for p in pools),'COUNTRIES',len(pools),flush=True)

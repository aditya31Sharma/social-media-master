import collections, concurrent.futures as cf, datetime, hashlib, json, random, re, secrets, subprocess
from pathlib import Path
from collect import DEST, TMP, LOG, GROUPS, fetch

GROUPS['Northern and Western Europe'][-1]=('denmark','Denmark',2)
GROUPS['East Asia'][-1]=('china','China',2)
GROUPS['Oceania']=[('australia','Australia',5),('new-zealand','New Zealand',5)]
PICTURES=DEST/'photos'
PICTURES.mkdir(exist_ok=True)
SEED=secrets.randbits(64)
PATTERN=r'username:"([^"\\]+)",bio:[\s\S]*?,url:"(https://www\.instagram\.com/[^"\\]+)",pictureUrl:"([^"\\]+)"[\s\S]*?,location:"([^"\\]*)"'

def collect_country(task):
 region,slug,country,quota=task
 page='https://www.modash.io/find-influencers/'+slug
 local=TMP/(slug+'.html')
 if local.exists(): html=local.read_text()
 else:
  raw,_=fetch(page);local.write_bytes(raw);html=raw.decode()
 candidates=[]
 for username,profile,picture,location in re.findall(PATTERN,html):
  if location==country and re.fullmatch(r'[A-Za-z0-9_.]{1,30}',username):
   candidates.append(dict(username=username,instagram_url=profile,country_or_territory=country,region=region,source_location=location,source_page=page,profile_picture_source_url=picture))
 candidates=list({r['username']:r for r in candidates}.values())
 random.Random(str(SEED)+slug).shuffle(candidates)
 chosen=[];failures=[]
 for row in candidates:
  if len(chosen)==quota:break
  try:
   raw,mime=fetch(row['profile_picture_source_url'])
   if not mime.startswith('image/'):raise ValueError('Non-image content: '+mime)
   original=TMP/(row['username']+'.image')
   original.write_bytes(raw)
   out=PICTURES/(row['username']+'.jpg')
   command=['sips','-s','format','jpeg','-s','formatOptions','60','-Z','96',str(original),'--out',str(out)]
   subprocess.run(command,check=True,capture_output=True)
   props=subprocess.run(['sips','-g','pixelWidth','-g','pixelHeight',str(out)],check=True,capture_output=True,text=True).stdout
   width=int(re.search(r'pixelWidth: (\d+)',props)[1]);height=int(re.search(r'pixelHeight: (\d+)',props)[1])
   if min(width,height)<32 or max(width,height)>96:raise ValueError('Unexpected image dimensions')
   data=out.read_bytes()
   if len(data)>=100000:raise ValueError('Photo too large')
   row.update(profile_picture='photos/'+out.name,photo_bytes=len(data),width=width,height=height,sha256=hashlib.sha256(data).hexdigest(),retrieved_at=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'))
   chosen.append(row)
  except Exception as e:failures.append({'username':row['username'],'error':str(e)})
 print(slug,len(chosen),'/',quota,'eligible',len(candidates),'failures',len(failures),flush=True)
 return dict(region=region,country=country,requested=quota,eligible_count=len(candidates),eligible_usernames=[r['username'] for r in candidates],users=chosen,failures=failures)

if __name__=='__main__':
 tasks=[(region,*c) for region,countries in GROUPS.items() for c in countries]
 results=[]
 with cf.ThreadPoolExecutor(max_workers=6) as pool:
  futures={pool.submit(collect_country,t):t for t in tasks}
  for future in cf.as_completed(futures):
   try:results.append(future.result())
   except Exception as e:
    task=futures[future];print('ERROR',task[1],str(e),flush=True);results.append(dict(region=task[0],country=task[2],requested=task[3],eligible_count=0,users=[],error=str(e)))
 results.sort(key=lambda r:(r['region'],r['country']))
 (TMP/'download-results.json').write_text(json.dumps({'random_seed':SEED,'results':results},ensure_ascii=False,indent=2))
 users=[u for r in results for u in r['users']]
 random.Random(SEED).shuffle(users)
 report={'schema_version':1,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'count':len(users),'sampling':{'method':'Stratified random selection without replacement from publicly listed Instagram profiles, with fixed country quotas and 10 accounts per region.','random_seed':SEED,'frame':'Modash public country directories; only profiles with an explicit matching creator location are eligible. This is a directory-based sample, not a uniform sample of all Instagram accounts.','location_basis':'Modash profile.location field, not audience geography or inferred ethnicity.','image_basis':'Profile pictures served by Modash image proxy, downloaded at collection time; direct live Instagram verification was unavailable.','image_processing':'JPEG, maximum 96 pixels on the longest side, quality 60.','country_pools':[{'country_or_territory':r['country'],'region':r['region'],'eligible_count':r['eligible_count'],'selected_count':len(r['users'])} for r in results]},'region_counts':dict(sorted(collections.Counter(u['region'] for u in users).items())),'country_or_territory_counts':dict(sorted(collections.Counter(u['country_or_territory'] for u in users).items())),'total_photo_bytes':sum(u['photo_bytes'] for u in users),'users':users}
 (DEST/'instagram_users.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 with LOG.open('a') as f:f.write('| Tool run | Downloaded '+str(len(users))+' DPs using verified creator-location fields; compressed to 96-pixel JPEGs; wrote JSON with source URLs and sampling details. |\n')
 print('RESULT',len(users),'PHOTOS_BYTES',report['total_photo_bytes'],'REGIONS',report['region_counts'],flush=True)

(async () => {
  const $ = s => document.querySelector(s), checks = [];
  const assert = (name, ok) => { checks.push({ name, pass: !!ok }); if (!ok) throw new Error(name); };
  const wait = async predicate => {
    for (let i = 0; i < 100; i++) { if (predicate()) return; await new Promise(r => setTimeout(r, 30)); }
    throw new Error('Timed out waiting for UI');
  };
  const input = (selector, value, event = 'input') => { $(selector).value = value; $(selector).dispatchEvent(new Event(event, { bubbles: true })); };
  await wait(() => !$('#download').disabled);
  assert('100 profiles loaded', $('#profile').options.length === 100);
  assert('Local Roboto loaded', document.fonts.check('700 42px StoryRoboto'));
  assert('Figma frame dimensions', $('#story').width === 1080 && $('#story').height === 2150);
  input('#profileSearch', '@danax');
  await wait(() => !$('#download').disabled);
  assert('Search selects correct profile', $('#profile').value === 'danaxbarghouti' && $('#story').getAttribute('aria-label').includes('danaxbarghouti'));
  input('#profileSearch', 'no-such-profile-999');
  assert('Empty search is handled', $('#profile').disabled && $('#profileCount').textContent.startsWith('0 of'));
  input('#profileSearch', '');
  await wait(() => !$('#download').disabled);
  assert('Clearing search restores 100 profiles', $('#profile').options.length === 100);
  const random = Math.random;
  try {
    Math.random = () => 0; $('#randomTime').click();
    assert('Randomizer includes 1', $('#timeValue').value === '1');
    Math.random = () => 0.999999; $('#randomTime').click();
    assert('Randomizer includes 60', $('#timeValue').value === '60');
  } finally { Math.random = random; }
  for (let i = 0; i < 250; i++) { $('#randomTime').click(); const n = Number($('#timeValue').value); if (n < 1 || n > 60 || !Number.isInteger(n)) throw new Error('Random out of range'); }
  assert('250 random values remain in range', true);
  document.querySelector('[data-unit=h]').click();
  assert('H switches preview to hours', $('#story').getAttribute('aria-label').includes('hours'));
  document.querySelector('[data-unit=m]').click();
  assert('M switches preview to minutes', $('#story').getAttribute('aria-label').includes('minutes'));
  input('#timeValue', '99', 'change'); assert('Time clamps at 60', $('#timeValue').value === '60');
  input('#timeValue', '0', 'change'); assert('Time clamps at 1', $('#timeValue').value === '1');
  input('#timeValue', ''); document.querySelector('[data-unit=h]').click();
  assert('Invalid time prevents export after redraw', $('#download').disabled);
  input('#timeValue', '3', 'change');
  input('#zoom', '1.5'); assert('Zoom changes position', $('#zoomValue').textContent === '150%');
  $('#resetPhoto').click(); assert('Reset restores crop', $('#zoomValue').textContent === '100%');
  const bitmapBlob = await new Promise(r => $('#story').toBlob(r));
  const pasteData = new DataTransfer(); pasteData.items.add(new File([bitmapBlob], 'clipboard-review.png', {type: 'image/png'}));
  window.dispatchEvent(new ClipboardEvent('paste', {clipboardData: pasteData}));
  await wait(() => $('#photoName').textContent === 'clipboard-review.png' && !$('#download').disabled);
  assert('Clipboard image becomes review photo', true);
  const invalid = new DataTransfer(); invalid.items.add(new File(['bad-image'], 'broken.png', {type: 'image/png'}));
  window.dispatchEvent(new DragEvent('drop', {dataTransfer: invalid}));
  await wait(() => $('#status').dataset.error === 'true');
  assert('Invalid image shows error and keeps previous image', $('#photoName').textContent === 'clipboard-review.png' && !$('#download').disabled);
  const dropData = new DataTransfer(); dropData.items.add(new File([bitmapBlob], 'dropped-review.png', {type: 'image/png'}));
  window.dispatchEvent(new DragEvent('drop', {dataTransfer: dropData}));
  await wait(() => $('#photoName').textContent === 'dropped-review.png' && !$('#download').disabled);
  assert('Drop image becomes review photo', true);
  const click = HTMLAnchorElement.prototype.click;
  try {
    HTMLAnchorElement.prototype.click = function () { window.__export = { url: this.href, name: this.download }; };
    for (const height of [2150, 1920]) {
      input('#format', String(height), 'change');
      const before = $('#story').toDataURL(); window.__export = null; $('#download').click();
      await wait(() => window.__export !== null);
      const blob = await (await fetch(window.__export.url)).blob(), bitmap = await createImageBitmap(blob);
      assert(`PNG exports 1080x${height}`, bitmap.width === 1080 && bitmap.height === height && blob.type === 'image/png');
      const out = document.createElement('canvas'); out.width = bitmap.width; out.height = bitmap.height; out.getContext('2d').drawImage(bitmap, 0, 0);
      assert(`Export equals preview pixels at ${height}`, before === out.toDataURL()); bitmap.close();
      assert(`Download filename at ${height}`, window.__export.name.endsWith('-story-3h.png'));
    }
  } finally { HTMLAnchorElement.prototype.click = click; }
  input('#format', '2150', 'change'); input('#timeValue', '3', 'change'); document.querySelector('[data-unit=m]').click();
  return { passed: checks.length, checks };
})()
